<!-- Created by and property of: Aidan Harney -->
<!-- Free use provided to: Perth's Allied Costumers -->
<!-- Said use can by revoked by said owner at any time -->

<?php
	echo "<input type='submit' name='preview_edit_button' value='Preview Post'/> <input type='submit' name='edit_button' value='Update Post'/>"
?>