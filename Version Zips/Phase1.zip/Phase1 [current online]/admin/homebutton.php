<!-- Created by and property of: Aidan Harney -->
<!-- Free use provided to: Perth's Allied Costumers -->
<!-- Said use can by revoked by said owner at any time -->

<a href="http://perthsalliedcostumers.org/">Go to PAC.org ></a>