<!-- Created by and property of: Aidan Harney -->
<!-- Free use provided to: Perth's Allied Costumers -->
<!-- Said use can by revoked by said owner at any time -->

<a href="?go=version">Version 1.0.1</a><br/>Created by <a href="mailto:aido727@gmail.com">Aidan Harney</a>