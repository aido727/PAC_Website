<!-- Created by and property of: Aidan Harney -->
<!-- Free use provided to: Perth's Allied Costumers -->
<!-- Said use can by revoked by said owner at any time -->

<!--Social Media-->
<div class="sidebarheader orangecomicborder topsidebarheader"><a class="invisible-link" href="https://www.facebook.com/PerthsAlliedCostumers"><span class="comiccapital">F</span>ACEBOOK</a></div>
<!--Facebook-->
<div id="facebook" class="comicborder maxsidebarwidth popupshadow">
	<div class="facebook-loading"></div>
	<div class="fb-page" data-href="https://www.facebook.com/PerthsAlliedCostumers" data-width="292" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true" data-show-posts="false"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/PerthsAlliedCostumers"><a href="https://www.facebook.com/PerthsAlliedCostumers">Perth&#039;s Allied Costumers</a></blockquote></div></div>
</div>

<!--Newsletter-->
<div class="sidebarheader orangecomicborder"><a class="invisible-link" href="http://perthsalliedcostumers.us11.list-manage1.com/subscribe?u=866668110840e947df720e666&id=eb2c81d719"><span class="comiccapital">N</span>EWSLETTER</a></div>
<div id="newsletter" class="comicborder maxsidebarwidth popupshadow">
	<a href="http://perthsalliedcostumers.us11.list-manage1.com/subscribe?u=866668110840e947df720e666&id=eb2c81d719" class="nl-b nl-b-full"><img src="images/newsletter.png" alt="Sign Up!" /></a>
</div>

<!--Videos-->
<div class="sidebarheader orangecomicborder"><!--<a class="invisible-link" href="?go=videos">--><span class="comiccapital">V</span>IDEOS<!--</a>--></div>
<!--YouTube-->
<a href="https://www.youtube.com/channel/UCQfq9OnhkYHlchfR1d0xvzw">
	<div id="youtube" class="comicborder maxsidebarwidth popupshadow">
		<div class="g-ytsubscribe" data-channelid="UCQfq9OnhkYHlchfR1d0xvzw" data-layout="full" data-count="default"></div>
	</div>
</a>

<!--Photos-->
<div class="sidebarheader orangecomicborder"><!--<a class="invisible-link" href="?go=photos">--><span class="comiccapital">P</span>HOTOS<!--</a>--></div>
<!--Instagram-->
<div id="instagram" class="comicborder popupshadow">
	<a href="http://instagram.com/perthsalliedcostumers?ref=badge" class="ig-b ig-b-full"><img src="images/instagram.png" alt="Instagram" /></a>
</div>
<!--Flickr-->
<div id="flickr" class="comicborder popupshadow">
	<a href="http://www.flickr.com/photos/perthsalliedcostumers/" class="fr-b fr-b-full"><img src="images/flickr.png" alt="Flickr"></a>
</div>

