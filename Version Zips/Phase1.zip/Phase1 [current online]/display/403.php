<!-- Created by and property of: Aidan Harney -->
<!-- Free use provided to: Perth's Allied Costumers -->
<!-- Said use can by revoked by said owner at any time -->

<?php
	$errCode = "403";
	$errTitle = "Forbidden";
	$errText = "You aren't meant to be here... turn back now!";
	
	include "display/errordisplay.php";
?>