<!-- Created by and property of: Aidan Harney -->
<!-- Free use provided to: Perth's Allied Costumers -->
<!-- Said use can by revoked by said owner at any time -->

<?php
	$errCode = "500";
	$errTitle = "Internal Server Error";
	$errText = "Oops! Looks like we stuffed something up...";
	
	include "display/errordisplay.php";
?>