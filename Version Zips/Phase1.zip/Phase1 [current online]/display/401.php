<!-- Created by and property of: Aidan Harney -->
<!-- Free use provided to: Perth's Allied Costumers -->
<!-- Said use can by revoked by said owner at any time -->

<?php
	$errCode = "401";
	$errTitle = "Unauthorized";
	$errText = "Access DENIED!";
	
	include "display/errordisplay.php";
?>