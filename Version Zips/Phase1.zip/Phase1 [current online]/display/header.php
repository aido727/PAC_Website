<!-- Created by and property of: Aidan Harney -->
<!-- Free use provided to: Perth's Allied Costumers -->
<!-- Said use can by revoked by said owner at any time -->

<div id="header-logo"><img src="images/HeaderLogo.png"/></div>
<div id="header-title"><img src="images/HeaderTitle.png"/></div>
<div id="header-shade-top"></div>
<div id="header-shade-bottom"></div>
<div id="header-scroll">
	<div class="header-loading"></div>
	<div class="innerScrollArea hide-until-loaded"></div>
</div>