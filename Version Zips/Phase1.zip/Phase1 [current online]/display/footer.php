<!-- Created by and property of: Aidan Harney -->
<!-- Free use provided to: Perth's Allied Costumers -->
<!-- Said use can by revoked by said owner at any time -->

<div id="footer-comicbox" class="orangecomicborder popupshadow">PAC is a club based on copyrighted and trademarked properties and is therefore not authorised to profit from any sales of merchandise bearing images or ideas from any intellectual property we are seen to be representing. PAC recognizes that it's members have no claim to the copyright and intellectual property of characters they represent except by the privileges authorised by the owners’ organisation/s.</div>