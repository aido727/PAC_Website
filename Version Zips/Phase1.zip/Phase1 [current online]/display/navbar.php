<!-- Created by and property of: Aidan Harney -->
<!-- Free use provided to: Perth's Allied Costumers -->
<!-- Said use can by revoked by said owner at any time -->

<?php include 'scripts/navbarAnim.js';?>
<div id="nav-table" class="table">
	<div class="table-row">
		<div id="nav-link-news" class="nav-link table-cell nav-link-b nav-link-news-b-full"><a class="nav-link-text" href='?go=news'>WHAT'S NEW?</a></div>
		<!--<div id="nav-link-events" class="nav-link table-cell"><a class="nav-link-text" href='?go=events'>EVENTS</a></div>
		<div id="nav-link-archive" class="nav-link table-cell"><a class="nav-link-text" href='?go=archive'>ARCHIVE</a></div>
		<div id="nav-link-photos" class="nav-link table-cell"><a class="nav-link-text" href='?go=photos'>PHOTOS</a></div>
		<div id="nav-link-videos" class="nav-link table-cell"><a class="nav-link-text" href='?go=videos'>VIDEOS</a></div>-->
		<div id="nav-link-about" class="nav-link table-cell nav-link-b nav-link-about-b-full"><a class="nav-link-text" href='?go=about'>ABOUT</a></div>
		<div id="nav-link-contact" class="nav-link table-cell nav-link-b nav-link-contact-b-full"><a class="nav-link-text" href='?go=contact'>CONTACT</a></div>
	</div>
</div>