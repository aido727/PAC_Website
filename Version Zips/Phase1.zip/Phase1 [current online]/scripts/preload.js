<script language="JavaScript" type="text/javascript">
/**	Created by and property of: Aidan Harney
	Free use provided to: Perth's Allied Costumers
	Said use can by revoked by said owner at any time **/
	
	/*spinners*/
	$(window).load(function(){
		$("#main-inner-loading").fadeOut("fast");
		$("#main-inner").fadeIn("fast");
		$(".header-loading").fadeOut("fast");
		$(".innerScrollArea").fadeIn("slow");
	});
</script>