<?php
//declare all globals here
$GLOBALS['count1'] = 0;
?>